﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_W09_Clothing_Shop
{
    public partial class Form_Shop : Form
    {
        DataTable dt_Cart = new DataTable();
        OpenFileDialog ofd = new OpenFileDialog();
        public Form_Shop()
        {
            InitializeComponent();
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = true;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jeweleries.Visible = false;
            pnl_Others.Visible = false;
        }

        private void Form_Shop_Load(object sender, EventArgs e)
        {
            dt_Cart.Columns.Add("Item Name"); 
            dt_Cart.Columns.Add("Quantity");
            dt_Cart.Columns.Add("Price");
            dt_Cart.Columns.Add("Total");
            dgv_Cart.DataSource = dt_Cart;
            totals();
        }

        private void btn_AddBasicTee_Click(object sender, EventArgs e)
        {
            addclick(lbl_BasicTee.Text, 175000);
        }
        private void addclick(string nama, int harga)
        {
            bool sama = false;
            int x = 0;
            for (int i = 0; i < dt_Cart.Rows.Count; i++)
            {
                if (dt_Cart.Rows[i][0].ToString() == nama)
                {
                    sama = true;
                    x = i;
                }
            }
            if (sama == true)
            {
                updatecart(x);
            }
            if (sama == false)
            {
                addtocart(nama, 1, harga);
            }
            totals();
        }
        private void totals()
        {
            int subtotal = 0;
            for(int i = 0; i < dt_Cart.Rows.Count; i++)
            {
                subtotal += Convert.ToInt32 (dt_Cart.Rows[i][3]);
            }
            double total = 0.1 * subtotal + subtotal;
            txtbox_SubTotal.Text = subtotal.ToString("C");
            txtbox_Total.Text = total.ToString("C");
        }
        private void updatecart(int x)
        {
            dt_Cart.Rows[x][1] = Convert.ToInt32(dt_Cart.Rows[x][1]) + 1;
            dt_Cart.Rows[x][3] = Convert.ToInt32(dt_Cart.Rows[x][1]) * Convert.ToInt32(dt_Cart.Rows[x][2]);
        }
        private void addtocart(string itemname, int qty, int price)
        {
            int total = qty * price;
            dt_Cart.Rows.Add(itemname, qty, price, total);
        }

        private void btn_AddCropTee_Click(object sender, EventArgs e)
        {
            addclick(lbl_CropTee.Text, 140000);
        }

        private void btn_AddGraphicTee_Click(object sender, EventArgs e)
        {
            addclick(lbl_GraphicTee.Text, 160500);
        }

        private void btn_AddPeterpanBlouse_Click(object sender, EventArgs e)
        {
            addclick(lbl_PeterpanBlouse.Text, 149900);
        }
        private void btn_AddNotchBlouse_Click(object sender, EventArgs e)
        {
            addclick(lbl_NotchBlouse.Text, 120000);
        }

        private void btn_AddPrintedBlouse_Click(object sender, EventArgs e)
        {
            addclick(lbl_PrintedBlouse.Text, 149900);
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = true;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jeweleries.Visible = false;
            pnl_Others.Visible = false;
        }
        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = true;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jeweleries.Visible = false;
            pnl_Others.Visible = false;
        }
        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = true;
            pnl_Shoes.Visible = false;
            pnl_Jeweleries.Visible = false;
            pnl_Others.Visible = false;
        }
        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = true;
            pnl_Jeweleries.Visible = false;
            pnl_Others.Visible = false;
        }
        private void jeweleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jeweleries.Visible = true;
            pnl_Others.Visible = false;
        }
        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jeweleries.Visible = false;
            pnl_Others.Visible = true;
        }

        private void btn_AddDrawstringShort_Click(object sender, EventArgs e)
        {
            addclick(lbl_DrawstringShorts.Text, 130000);
        }

        private void btn_AddCargoSkort_Click(object sender, EventArgs e)
        {
            addclick(lbl_CargoSkort.Text, 259900);
        }

        private void btn_AddPocketShorts_Click(object sender, EventArgs e)
        {
            addclick(lbl_PocketShorts.Text, 159900);
        }

        private void btn_AddCargoTrous_Click(object sender, EventArgs e)
        {
            addclick(lbl_CargoTrousers.Text, 379900);
        }

        private void btn_AddBoyfJeans_Click(object sender, EventArgs e)
        {
            addclick(lbl_BoyfriendJeans.Text, 299900);
        }

        private void btn_AddParachutePants_Click(object sender, EventArgs e)
        {
            addclick(lbl_ParachutePants.Text, 200000);
        }

        private void btn_AddEspadrilles_Click(object sender, EventArgs e)
        {
            addclick(lbl_CanvasEspadrilles.Text, 359900);
        }

        private void btn_AddFlats_Click(object sender, EventArgs e)
        {
            addclick(lbl_BalletFlats.Text, 399900);
        }

        private void btn_AddSneakers_Click(object sender, EventArgs e)
        {
            addclick(lbl_CanvasSneakers.Text, 580000);
        }

        private void btn_AddHeart_Click(object sender, EventArgs e)
        {
            addclick(lbl_HeartPendant.Text, 170000);
        }

        private void btn_AddDome_Click(object sender, EventArgs e)
        {
            addclick(lbl_ChunkyDome.Text, 359000);
        }

        private void btn_AddRing_Click(object sender, EventArgs e)
        {
            addclick(lbl_RingPendant.Text, 249900);
        }

        private void btn_Upload_Click(object sender, EventArgs e)
        {
            ofd.Filter = "Pictures|*.jpeg;*.jpg;*.png;*.bmp;*.gif;*.icon;*.emf;*.exif;*.tiff;*.wmf";
            ofd.ShowDialog();
            pbox_Others.Image = new Bitmap($"{ofd.FileName}");
            txtbox_ItemName.Enabled = true;
            txtbox_ItemPrice.Enabled = true;
        }

        private void txtbox_ItemName_TextChanged(object sender, EventArgs e)
        {
            if(txtbox_ItemName.Text != "" && txtbox_ItemPrice.Text != "")
            {
                btn_AddNewItem.Enabled = true;
            }
            else
            {
                btn_AddNewItem.Enabled = false;
            }
        }

        private void txtbox_ItemPrice_TextChanged(object sender, EventArgs e)
        {
            if (txtbox_ItemName.Text != "" && txtbox_ItemPrice.Text != "")
            {
                btn_AddNewItem.Enabled = true;
            }
            else
            {
                btn_AddNewItem.Enabled = false;
            }
        }

        private void btn_AddNewItem_Click(object sender, EventArgs e)
        {
            addclick(txtbox_ItemName.Text, Convert.ToInt32 (txtbox_ItemPrice.Text));
            pbox_Others.Image = null;
            txtbox_ItemName.Clear();
            txtbox_ItemPrice.Clear();
            txtbox_ItemName.Enabled = false;
            txtbox_ItemPrice.Enabled = false;
        }

        private void txtbox_ItemPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }
        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if(dgv_Cart.SelectedCells.Count > 0)
            {
                int i = 0;
                i = dgv_Cart.CurrentRow.Index;
                dt_Cart.Rows.RemoveAt(i);
                totals();
            }
            else
            {
                MessageBox.Show("Please Select An Item");
            }
        }
    }
}
