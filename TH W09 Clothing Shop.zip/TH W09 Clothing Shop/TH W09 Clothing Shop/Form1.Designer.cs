﻿namespace TH_W09_Clothing_Shop
{
    partial class Form_Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jeweleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_Cart = new System.Windows.Forms.DataGridView();
            this.lbl_SubTotal = new System.Windows.Forms.Label();
            this.txtbox_SubTotal = new System.Windows.Forms.TextBox();
            this.txtbox_Total = new System.Windows.Forms.TextBox();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.lbl_BasicTee = new System.Windows.Forms.Label();
            this.btn_AddBasicTee = new System.Windows.Forms.Button();
            this.lbl_HargaBasicTee = new System.Windows.Forms.Label();
            this.lbl_HargaCropTee = new System.Windows.Forms.Label();
            this.btn_AddCropTee = new System.Windows.Forms.Button();
            this.lbl_CropTee = new System.Windows.Forms.Label();
            this.lbl_HargaGraphicTee = new System.Windows.Forms.Label();
            this.btn_AddGraphicTee = new System.Windows.Forms.Button();
            this.lbl_GraphicTee = new System.Windows.Forms.Label();
            this.pnl_TShirt = new System.Windows.Forms.Panel();
            this.pbox_croptee = new System.Windows.Forms.PictureBox();
            this.pbox_basictee = new System.Windows.Forms.PictureBox();
            this.pbox_graphictee = new System.Windows.Forms.PictureBox();
            this.pnl_Shirt = new System.Windows.Forms.Panel();
            this.pbox_NotchCollarBlouse = new System.Windows.Forms.PictureBox();
            this.lbl_HargaPrintedBlouse = new System.Windows.Forms.Label();
            this.pbox_PeterpanCollarBlouse = new System.Windows.Forms.PictureBox();
            this.btn_AddPrintedBlouse = new System.Windows.Forms.Button();
            this.pbox_PrintedBlouse = new System.Windows.Forms.PictureBox();
            this.lbl_PrintedBlouse = new System.Windows.Forms.Label();
            this.lbl_PeterpanBlouse = new System.Windows.Forms.Label();
            this.lbl_HargaNotchBlouse = new System.Windows.Forms.Label();
            this.btn_AddPeterpanBlouse = new System.Windows.Forms.Button();
            this.btn_AddNotchBlouse = new System.Windows.Forms.Button();
            this.lbl_HargaPeterpanBlouse = new System.Windows.Forms.Label();
            this.lbl_NotchBlouse = new System.Windows.Forms.Label();
            this.pnl_Pants = new System.Windows.Forms.Panel();
            this.pbox_CargoSkort = new System.Windows.Forms.PictureBox();
            this.lbl_HargaPocketShorts = new System.Windows.Forms.Label();
            this.pbox_DrawstringShorts = new System.Windows.Forms.PictureBox();
            this.btn_AddPocketShorts = new System.Windows.Forms.Button();
            this.pbox_PocketShorts = new System.Windows.Forms.PictureBox();
            this.lbl_PocketShorts = new System.Windows.Forms.Label();
            this.lbl_DrawstringShorts = new System.Windows.Forms.Label();
            this.lbl_HargaCargoSkort = new System.Windows.Forms.Label();
            this.btn_AddDrawstringShort = new System.Windows.Forms.Button();
            this.btn_AddCargoSkort = new System.Windows.Forms.Button();
            this.lbl_HargaDrawstringShorts = new System.Windows.Forms.Label();
            this.lbl_CargoSkort = new System.Windows.Forms.Label();
            this.pnl_LongPants = new System.Windows.Forms.Panel();
            this.pbox_BoyfriendJeans = new System.Windows.Forms.PictureBox();
            this.lbl_HargaParachute = new System.Windows.Forms.Label();
            this.pbox_CargoTrousers = new System.Windows.Forms.PictureBox();
            this.btn_AddParachutePants = new System.Windows.Forms.Button();
            this.pbox_ParachutePants = new System.Windows.Forms.PictureBox();
            this.lbl_ParachutePants = new System.Windows.Forms.Label();
            this.lbl_CargoTrousers = new System.Windows.Forms.Label();
            this.lbl_HargaBoyfriend = new System.Windows.Forms.Label();
            this.btn_AddCargoTrous = new System.Windows.Forms.Button();
            this.btn_AddBoyfJeans = new System.Windows.Forms.Button();
            this.lbl_HargaCargoTrous = new System.Windows.Forms.Label();
            this.lbl_BoyfriendJeans = new System.Windows.Forms.Label();
            this.pnl_Shoes = new System.Windows.Forms.Panel();
            this.pbox_BalletFlats = new System.Windows.Forms.PictureBox();
            this.lbl_HargaCanvas = new System.Windows.Forms.Label();
            this.pbox_CanvasEspadrilles = new System.Windows.Forms.PictureBox();
            this.btn_AddSneakers = new System.Windows.Forms.Button();
            this.pbox_CanvasSneakers = new System.Windows.Forms.PictureBox();
            this.lbl_CanvasSneakers = new System.Windows.Forms.Label();
            this.lbl_CanvasEspadrilles = new System.Windows.Forms.Label();
            this.lbl_HargaBallet = new System.Windows.Forms.Label();
            this.btn_AddEspadrilles = new System.Windows.Forms.Button();
            this.btn_AddFlats = new System.Windows.Forms.Button();
            this.lbl_HargaEspadrilles = new System.Windows.Forms.Label();
            this.lbl_BalletFlats = new System.Windows.Forms.Label();
            this.pnl_Jeweleries = new System.Windows.Forms.Panel();
            this.pbox_ChunkyDome = new System.Windows.Forms.PictureBox();
            this.lbl_HargaRing = new System.Windows.Forms.Label();
            this.pbox_HeartPendant = new System.Windows.Forms.PictureBox();
            this.btn_AddRing = new System.Windows.Forms.Button();
            this.pbox_RingPendant = new System.Windows.Forms.PictureBox();
            this.lbl_RingPendant = new System.Windows.Forms.Label();
            this.lbl_HeartPendant = new System.Windows.Forms.Label();
            this.lbl_HargaDome = new System.Windows.Forms.Label();
            this.btn_AddHeart = new System.Windows.Forms.Button();
            this.btn_AddDome = new System.Windows.Forms.Button();
            this.lbl_HargaHeart = new System.Windows.Forms.Label();
            this.lbl_ChunkyDome = new System.Windows.Forms.Label();
            this.pnl_Others = new System.Windows.Forms.Panel();
            this.txtbox_ItemPrice = new System.Windows.Forms.TextBox();
            this.lbl_ItemPrice = new System.Windows.Forms.Label();
            this.txtbox_ItemName = new System.Windows.Forms.TextBox();
            this.lbl_ItemName = new System.Windows.Forms.Label();
            this.btn_Upload = new System.Windows.Forms.Button();
            this.pbox_Others = new System.Windows.Forms.PictureBox();
            this.lbl_Upload = new System.Windows.Forms.Label();
            this.btn_AddNewItem = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Cart)).BeginInit();
            this.pnl_TShirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_croptee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_basictee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_graphictee)).BeginInit();
            this.pnl_Shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_NotchCollarBlouse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_PeterpanCollarBlouse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_PrintedBlouse)).BeginInit();
            this.pnl_Pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_CargoSkort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DrawstringShorts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_PocketShorts)).BeginInit();
            this.pnl_LongPants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_BoyfriendJeans)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_CargoTrousers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_ParachutePants)).BeginInit();
            this.pnl_Shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_BalletFlats)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_CanvasEspadrilles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_CanvasSneakers)).BeginInit();
            this.pnl_Jeweleries.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_ChunkyDome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_HeartPendant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_RingPendant)).BeginInit();
            this.pnl_Others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_Others)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1032, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jeweleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jeweleriesToolStripMenuItem
            // 
            this.jeweleriesToolStripMenuItem.Name = "jeweleriesToolStripMenuItem";
            this.jeweleriesToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.jeweleriesToolStripMenuItem.Text = "Jeweleries";
            this.jeweleriesToolStripMenuItem.Click += new System.EventHandler(this.jeweleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv_Cart
            // 
            this.dgv_Cart.AllowUserToAddRows = false;
            this.dgv_Cart.AllowUserToDeleteRows = false;
            this.dgv_Cart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Cart.Location = new System.Drawing.Point(577, 40);
            this.dgv_Cart.Name = "dgv_Cart";
            this.dgv_Cart.ReadOnly = true;
            this.dgv_Cart.Size = new System.Drawing.Size(443, 327);
            this.dgv_Cart.TabIndex = 1;
            // 
            // lbl_SubTotal
            // 
            this.lbl_SubTotal.AutoSize = true;
            this.lbl_SubTotal.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SubTotal.Location = new System.Drawing.Point(573, 370);
            this.lbl_SubTotal.Name = "lbl_SubTotal";
            this.lbl_SubTotal.Size = new System.Drawing.Size(87, 23);
            this.lbl_SubTotal.TabIndex = 2;
            this.lbl_SubTotal.Text = "Sub Total:";
            // 
            // txtbox_SubTotal
            // 
            this.txtbox_SubTotal.Enabled = false;
            this.txtbox_SubTotal.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_SubTotal.Location = new System.Drawing.Point(666, 368);
            this.txtbox_SubTotal.Name = "txtbox_SubTotal";
            this.txtbox_SubTotal.Size = new System.Drawing.Size(160, 31);
            this.txtbox_SubTotal.TabIndex = 3;
            // 
            // txtbox_Total
            // 
            this.txtbox_Total.Enabled = false;
            this.txtbox_Total.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_Total.Location = new System.Drawing.Point(666, 394);
            this.txtbox_Total.Name = "txtbox_Total";
            this.txtbox_Total.Size = new System.Drawing.Size(160, 31);
            this.txtbox_Total.TabIndex = 5;
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.Location = new System.Drawing.Point(606, 396);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(54, 23);
            this.lbl_Total.TabIndex = 4;
            this.lbl_Total.Text = "Total:";
            // 
            // lbl_BasicTee
            // 
            this.lbl_BasicTee.AutoSize = true;
            this.lbl_BasicTee.Location = new System.Drawing.Point(9, 225);
            this.lbl_BasicTee.Name = "lbl_BasicTee";
            this.lbl_BasicTee.Size = new System.Drawing.Size(96, 13);
            this.lbl_BasicTee.TabIndex = 9;
            this.lbl_BasicTee.Text = "Basic Fitted T-Shirt";
            // 
            // btn_AddBasicTee
            // 
            this.btn_AddBasicTee.Location = new System.Drawing.Point(12, 268);
            this.btn_AddBasicTee.Name = "btn_AddBasicTee";
            this.btn_AddBasicTee.Size = new System.Drawing.Size(75, 23);
            this.btn_AddBasicTee.TabIndex = 10;
            this.btn_AddBasicTee.Text = "Add To Cart";
            this.btn_AddBasicTee.UseVisualStyleBackColor = true;
            this.btn_AddBasicTee.Click += new System.EventHandler(this.btn_AddBasicTee_Click);
            // 
            // lbl_HargaBasicTee
            // 
            this.lbl_HargaBasicTee.AutoSize = true;
            this.lbl_HargaBasicTee.Location = new System.Drawing.Point(9, 244);
            this.lbl_HargaBasicTee.Name = "lbl_HargaBasicTee";
            this.lbl_HargaBasicTee.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaBasicTee.TabIndex = 11;
            this.lbl_HargaBasicTee.Text = "Rp. 175.000,-";
            // 
            // lbl_HargaCropTee
            // 
            this.lbl_HargaCropTee.AutoSize = true;
            this.lbl_HargaCropTee.Location = new System.Drawing.Point(190, 244);
            this.lbl_HargaCropTee.Name = "lbl_HargaCropTee";
            this.lbl_HargaCropTee.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaCropTee.TabIndex = 14;
            this.lbl_HargaCropTee.Text = "Rp. 140.000,-";
            // 
            // btn_AddCropTee
            // 
            this.btn_AddCropTee.Location = new System.Drawing.Point(193, 268);
            this.btn_AddCropTee.Name = "btn_AddCropTee";
            this.btn_AddCropTee.Size = new System.Drawing.Size(75, 23);
            this.btn_AddCropTee.TabIndex = 13;
            this.btn_AddCropTee.Text = "Add To Cart";
            this.btn_AddCropTee.UseVisualStyleBackColor = true;
            this.btn_AddCropTee.Click += new System.EventHandler(this.btn_AddCropTee_Click);
            // 
            // lbl_CropTee
            // 
            this.lbl_CropTee.AutoSize = true;
            this.lbl_CropTee.Location = new System.Drawing.Point(190, 225);
            this.lbl_CropTee.Name = "lbl_CropTee";
            this.lbl_CropTee.Size = new System.Drawing.Size(127, 13);
            this.lbl_CropTee.TabIndex = 12;
            this.lbl_CropTee.Text = "Round Neck Crop T-Shirt";
            // 
            // lbl_HargaGraphicTee
            // 
            this.lbl_HargaGraphicTee.AutoSize = true;
            this.lbl_HargaGraphicTee.Location = new System.Drawing.Point(372, 244);
            this.lbl_HargaGraphicTee.Name = "lbl_HargaGraphicTee";
            this.lbl_HargaGraphicTee.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaGraphicTee.TabIndex = 17;
            this.lbl_HargaGraphicTee.Text = "Rp. 160.500,-";
            // 
            // btn_AddGraphicTee
            // 
            this.btn_AddGraphicTee.Location = new System.Drawing.Point(375, 268);
            this.btn_AddGraphicTee.Name = "btn_AddGraphicTee";
            this.btn_AddGraphicTee.Size = new System.Drawing.Size(75, 23);
            this.btn_AddGraphicTee.TabIndex = 16;
            this.btn_AddGraphicTee.Text = "Add To Cart";
            this.btn_AddGraphicTee.UseVisualStyleBackColor = true;
            this.btn_AddGraphicTee.Click += new System.EventHandler(this.btn_AddGraphicTee_Click);
            // 
            // lbl_GraphicTee
            // 
            this.lbl_GraphicTee.AutoSize = true;
            this.lbl_GraphicTee.Location = new System.Drawing.Point(372, 225);
            this.lbl_GraphicTee.Name = "lbl_GraphicTee";
            this.lbl_GraphicTee.Size = new System.Drawing.Size(142, 13);
            this.lbl_GraphicTee.TabIndex = 15;
            this.lbl_GraphicTee.Text = "Short Sleeve Graphic T-Shirt";
            // 
            // pnl_TShirt
            // 
            this.pnl_TShirt.Controls.Add(this.pbox_croptee);
            this.pnl_TShirt.Controls.Add(this.lbl_HargaGraphicTee);
            this.pnl_TShirt.Controls.Add(this.pbox_basictee);
            this.pnl_TShirt.Controls.Add(this.btn_AddGraphicTee);
            this.pnl_TShirt.Controls.Add(this.pbox_graphictee);
            this.pnl_TShirt.Controls.Add(this.lbl_GraphicTee);
            this.pnl_TShirt.Controls.Add(this.lbl_BasicTee);
            this.pnl_TShirt.Controls.Add(this.lbl_HargaCropTee);
            this.pnl_TShirt.Controls.Add(this.btn_AddBasicTee);
            this.pnl_TShirt.Controls.Add(this.btn_AddCropTee);
            this.pnl_TShirt.Controls.Add(this.lbl_HargaBasicTee);
            this.pnl_TShirt.Controls.Add(this.lbl_CropTee);
            this.pnl_TShirt.Location = new System.Drawing.Point(9, 27);
            this.pnl_TShirt.Name = "pnl_TShirt";
            this.pnl_TShirt.Size = new System.Drawing.Size(543, 298);
            this.pnl_TShirt.TabIndex = 18;
            this.pnl_TShirt.Visible = false;
            // 
            // pbox_croptee
            // 
            this.pbox_croptee.Image = global::TH_W09_Clothing_Shop.Properties.Resources.roundcroptee;
            this.pbox_croptee.Location = new System.Drawing.Point(193, 13);
            this.pbox_croptee.Name = "pbox_croptee";
            this.pbox_croptee.Size = new System.Drawing.Size(142, 206);
            this.pbox_croptee.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_croptee.TabIndex = 7;
            this.pbox_croptee.TabStop = false;
            // 
            // pbox_basictee
            // 
            this.pbox_basictee.Image = global::TH_W09_Clothing_Shop.Properties.Resources.basictee;
            this.pbox_basictee.Location = new System.Drawing.Point(9, 13);
            this.pbox_basictee.Name = "pbox_basictee";
            this.pbox_basictee.Size = new System.Drawing.Size(143, 206);
            this.pbox_basictee.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_basictee.TabIndex = 6;
            this.pbox_basictee.TabStop = false;
            // 
            // pbox_graphictee
            // 
            this.pbox_graphictee.Image = global::TH_W09_Clothing_Shop.Properties.Resources.graphictee;
            this.pbox_graphictee.Location = new System.Drawing.Point(375, 13);
            this.pbox_graphictee.Name = "pbox_graphictee";
            this.pbox_graphictee.Size = new System.Drawing.Size(145, 206);
            this.pbox_graphictee.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_graphictee.TabIndex = 8;
            this.pbox_graphictee.TabStop = false;
            // 
            // pnl_Shirt
            // 
            this.pnl_Shirt.Controls.Add(this.pbox_NotchCollarBlouse);
            this.pnl_Shirt.Controls.Add(this.lbl_HargaPrintedBlouse);
            this.pnl_Shirt.Controls.Add(this.pbox_PeterpanCollarBlouse);
            this.pnl_Shirt.Controls.Add(this.btn_AddPrintedBlouse);
            this.pnl_Shirt.Controls.Add(this.pbox_PrintedBlouse);
            this.pnl_Shirt.Controls.Add(this.lbl_PrintedBlouse);
            this.pnl_Shirt.Controls.Add(this.lbl_PeterpanBlouse);
            this.pnl_Shirt.Controls.Add(this.lbl_HargaNotchBlouse);
            this.pnl_Shirt.Controls.Add(this.btn_AddPeterpanBlouse);
            this.pnl_Shirt.Controls.Add(this.btn_AddNotchBlouse);
            this.pnl_Shirt.Controls.Add(this.lbl_HargaPeterpanBlouse);
            this.pnl_Shirt.Controls.Add(this.lbl_NotchBlouse);
            this.pnl_Shirt.Location = new System.Drawing.Point(9, 27);
            this.pnl_Shirt.Name = "pnl_Shirt";
            this.pnl_Shirt.Size = new System.Drawing.Size(543, 298);
            this.pnl_Shirt.TabIndex = 19;
            this.pnl_Shirt.Visible = false;
            // 
            // pbox_NotchCollarBlouse
            // 
            this.pbox_NotchCollarBlouse.Image = global::TH_W09_Clothing_Shop.Properties.Resources.notchcollarblouse;
            this.pbox_NotchCollarBlouse.Location = new System.Drawing.Point(193, 13);
            this.pbox_NotchCollarBlouse.Name = "pbox_NotchCollarBlouse";
            this.pbox_NotchCollarBlouse.Size = new System.Drawing.Size(142, 206);
            this.pbox_NotchCollarBlouse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_NotchCollarBlouse.TabIndex = 7;
            this.pbox_NotchCollarBlouse.TabStop = false;
            // 
            // lbl_HargaPrintedBlouse
            // 
            this.lbl_HargaPrintedBlouse.AutoSize = true;
            this.lbl_HargaPrintedBlouse.Location = new System.Drawing.Point(372, 244);
            this.lbl_HargaPrintedBlouse.Name = "lbl_HargaPrintedBlouse";
            this.lbl_HargaPrintedBlouse.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaPrintedBlouse.TabIndex = 17;
            this.lbl_HargaPrintedBlouse.Text = "Rp. 149.900,-";
            // 
            // pbox_PeterpanCollarBlouse
            // 
            this.pbox_PeterpanCollarBlouse.Image = global::TH_W09_Clothing_Shop.Properties.Resources.peterpancollarblouse;
            this.pbox_PeterpanCollarBlouse.Location = new System.Drawing.Point(9, 13);
            this.pbox_PeterpanCollarBlouse.Name = "pbox_PeterpanCollarBlouse";
            this.pbox_PeterpanCollarBlouse.Size = new System.Drawing.Size(143, 206);
            this.pbox_PeterpanCollarBlouse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_PeterpanCollarBlouse.TabIndex = 6;
            this.pbox_PeterpanCollarBlouse.TabStop = false;
            // 
            // btn_AddPrintedBlouse
            // 
            this.btn_AddPrintedBlouse.Location = new System.Drawing.Point(375, 268);
            this.btn_AddPrintedBlouse.Name = "btn_AddPrintedBlouse";
            this.btn_AddPrintedBlouse.Size = new System.Drawing.Size(75, 23);
            this.btn_AddPrintedBlouse.TabIndex = 16;
            this.btn_AddPrintedBlouse.Text = "Add To Cart";
            this.btn_AddPrintedBlouse.UseVisualStyleBackColor = true;
            this.btn_AddPrintedBlouse.Click += new System.EventHandler(this.btn_AddPrintedBlouse_Click);
            // 
            // pbox_PrintedBlouse
            // 
            this.pbox_PrintedBlouse.Image = global::TH_W09_Clothing_Shop.Properties.Resources.printedblouse;
            this.pbox_PrintedBlouse.Location = new System.Drawing.Point(375, 13);
            this.pbox_PrintedBlouse.Name = "pbox_PrintedBlouse";
            this.pbox_PrintedBlouse.Size = new System.Drawing.Size(145, 206);
            this.pbox_PrintedBlouse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_PrintedBlouse.TabIndex = 8;
            this.pbox_PrintedBlouse.TabStop = false;
            // 
            // lbl_PrintedBlouse
            // 
            this.lbl_PrintedBlouse.AutoSize = true;
            this.lbl_PrintedBlouse.Location = new System.Drawing.Point(372, 225);
            this.lbl_PrintedBlouse.Name = "lbl_PrintedBlouse";
            this.lbl_PrintedBlouse.Size = new System.Drawing.Size(142, 13);
            this.lbl_PrintedBlouse.TabIndex = 15;
            this.lbl_PrintedBlouse.Text = "Printed Blouse with Front Tie";
            // 
            // lbl_PeterpanBlouse
            // 
            this.lbl_PeterpanBlouse.AutoSize = true;
            this.lbl_PeterpanBlouse.Location = new System.Drawing.Point(9, 225);
            this.lbl_PeterpanBlouse.Name = "lbl_PeterpanBlouse";
            this.lbl_PeterpanBlouse.Size = new System.Drawing.Size(114, 13);
            this.lbl_PeterpanBlouse.TabIndex = 9;
            this.lbl_PeterpanBlouse.Text = "Peterpan Collar Blouse";
            // 
            // lbl_HargaNotchBlouse
            // 
            this.lbl_HargaNotchBlouse.AutoSize = true;
            this.lbl_HargaNotchBlouse.Location = new System.Drawing.Point(190, 244);
            this.lbl_HargaNotchBlouse.Name = "lbl_HargaNotchBlouse";
            this.lbl_HargaNotchBlouse.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaNotchBlouse.TabIndex = 14;
            this.lbl_HargaNotchBlouse.Text = "Rp. 120.000,-";
            // 
            // btn_AddPeterpanBlouse
            // 
            this.btn_AddPeterpanBlouse.Location = new System.Drawing.Point(12, 268);
            this.btn_AddPeterpanBlouse.Name = "btn_AddPeterpanBlouse";
            this.btn_AddPeterpanBlouse.Size = new System.Drawing.Size(75, 23);
            this.btn_AddPeterpanBlouse.TabIndex = 10;
            this.btn_AddPeterpanBlouse.Text = "Add To Cart";
            this.btn_AddPeterpanBlouse.UseVisualStyleBackColor = true;
            this.btn_AddPeterpanBlouse.Click += new System.EventHandler(this.btn_AddPeterpanBlouse_Click);
            // 
            // btn_AddNotchBlouse
            // 
            this.btn_AddNotchBlouse.Location = new System.Drawing.Point(193, 268);
            this.btn_AddNotchBlouse.Name = "btn_AddNotchBlouse";
            this.btn_AddNotchBlouse.Size = new System.Drawing.Size(75, 23);
            this.btn_AddNotchBlouse.TabIndex = 13;
            this.btn_AddNotchBlouse.Text = "Add To Cart";
            this.btn_AddNotchBlouse.UseVisualStyleBackColor = true;
            this.btn_AddNotchBlouse.Click += new System.EventHandler(this.btn_AddNotchBlouse_Click);
            // 
            // lbl_HargaPeterpanBlouse
            // 
            this.lbl_HargaPeterpanBlouse.AutoSize = true;
            this.lbl_HargaPeterpanBlouse.Location = new System.Drawing.Point(9, 244);
            this.lbl_HargaPeterpanBlouse.Name = "lbl_HargaPeterpanBlouse";
            this.lbl_HargaPeterpanBlouse.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaPeterpanBlouse.TabIndex = 11;
            this.lbl_HargaPeterpanBlouse.Text = "Rp. 149.900,-";
            // 
            // lbl_NotchBlouse
            // 
            this.lbl_NotchBlouse.AutoSize = true;
            this.lbl_NotchBlouse.Location = new System.Drawing.Point(190, 225);
            this.lbl_NotchBlouse.Name = "lbl_NotchBlouse";
            this.lbl_NotchBlouse.Size = new System.Drawing.Size(100, 13);
            this.lbl_NotchBlouse.TabIndex = 12;
            this.lbl_NotchBlouse.Text = "Notch Collar Blouse";
            // 
            // pnl_Pants
            // 
            this.pnl_Pants.Controls.Add(this.pbox_CargoSkort);
            this.pnl_Pants.Controls.Add(this.lbl_HargaPocketShorts);
            this.pnl_Pants.Controls.Add(this.pbox_DrawstringShorts);
            this.pnl_Pants.Controls.Add(this.btn_AddPocketShorts);
            this.pnl_Pants.Controls.Add(this.pbox_PocketShorts);
            this.pnl_Pants.Controls.Add(this.lbl_PocketShorts);
            this.pnl_Pants.Controls.Add(this.lbl_DrawstringShorts);
            this.pnl_Pants.Controls.Add(this.lbl_HargaCargoSkort);
            this.pnl_Pants.Controls.Add(this.btn_AddDrawstringShort);
            this.pnl_Pants.Controls.Add(this.btn_AddCargoSkort);
            this.pnl_Pants.Controls.Add(this.lbl_HargaDrawstringShorts);
            this.pnl_Pants.Controls.Add(this.lbl_CargoSkort);
            this.pnl_Pants.Location = new System.Drawing.Point(12, 27);
            this.pnl_Pants.Name = "pnl_Pants";
            this.pnl_Pants.Size = new System.Drawing.Size(543, 298);
            this.pnl_Pants.TabIndex = 20;
            this.pnl_Pants.Visible = false;
            // 
            // pbox_CargoSkort
            // 
            this.pbox_CargoSkort.Image = global::TH_W09_Clothing_Shop.Properties.Resources.cargoskort;
            this.pbox_CargoSkort.Location = new System.Drawing.Point(193, 13);
            this.pbox_CargoSkort.Name = "pbox_CargoSkort";
            this.pbox_CargoSkort.Size = new System.Drawing.Size(142, 206);
            this.pbox_CargoSkort.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_CargoSkort.TabIndex = 7;
            this.pbox_CargoSkort.TabStop = false;
            // 
            // lbl_HargaPocketShorts
            // 
            this.lbl_HargaPocketShorts.AutoSize = true;
            this.lbl_HargaPocketShorts.Location = new System.Drawing.Point(372, 244);
            this.lbl_HargaPocketShorts.Name = "lbl_HargaPocketShorts";
            this.lbl_HargaPocketShorts.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaPocketShorts.TabIndex = 17;
            this.lbl_HargaPocketShorts.Text = "Rp. 159.900,-";
            // 
            // pbox_DrawstringShorts
            // 
            this.pbox_DrawstringShorts.Image = global::TH_W09_Clothing_Shop.Properties.Resources.drawstringshorts;
            this.pbox_DrawstringShorts.Location = new System.Drawing.Point(9, 13);
            this.pbox_DrawstringShorts.Name = "pbox_DrawstringShorts";
            this.pbox_DrawstringShorts.Size = new System.Drawing.Size(143, 206);
            this.pbox_DrawstringShorts.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_DrawstringShorts.TabIndex = 6;
            this.pbox_DrawstringShorts.TabStop = false;
            // 
            // btn_AddPocketShorts
            // 
            this.btn_AddPocketShorts.Location = new System.Drawing.Point(375, 268);
            this.btn_AddPocketShorts.Name = "btn_AddPocketShorts";
            this.btn_AddPocketShorts.Size = new System.Drawing.Size(75, 23);
            this.btn_AddPocketShorts.TabIndex = 16;
            this.btn_AddPocketShorts.Text = "Add To Cart";
            this.btn_AddPocketShorts.UseVisualStyleBackColor = true;
            this.btn_AddPocketShorts.Click += new System.EventHandler(this.btn_AddPocketShorts_Click);
            // 
            // pbox_PocketShorts
            // 
            this.pbox_PocketShorts.Image = global::TH_W09_Clothing_Shop.Properties.Resources.pocketshortpants;
            this.pbox_PocketShorts.Location = new System.Drawing.Point(375, 13);
            this.pbox_PocketShorts.Name = "pbox_PocketShorts";
            this.pbox_PocketShorts.Size = new System.Drawing.Size(145, 206);
            this.pbox_PocketShorts.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_PocketShorts.TabIndex = 8;
            this.pbox_PocketShorts.TabStop = false;
            // 
            // lbl_PocketShorts
            // 
            this.lbl_PocketShorts.AutoSize = true;
            this.lbl_PocketShorts.Location = new System.Drawing.Point(372, 225);
            this.lbl_PocketShorts.Name = "lbl_PocketShorts";
            this.lbl_PocketShorts.Size = new System.Drawing.Size(99, 13);
            this.lbl_PocketShorts.TabIndex = 15;
            this.lbl_PocketShorts.Text = "Pocket Short Pants";
            // 
            // lbl_DrawstringShorts
            // 
            this.lbl_DrawstringShorts.AutoSize = true;
            this.lbl_DrawstringShorts.Location = new System.Drawing.Point(9, 225);
            this.lbl_DrawstringShorts.Name = "lbl_DrawstringShorts";
            this.lbl_DrawstringShorts.Size = new System.Drawing.Size(139, 13);
            this.lbl_DrawstringShorts.TabIndex = 9;
            this.lbl_DrawstringShorts.Text = "Paperbag Drawstring Shorts";
            // 
            // lbl_HargaCargoSkort
            // 
            this.lbl_HargaCargoSkort.AutoSize = true;
            this.lbl_HargaCargoSkort.Location = new System.Drawing.Point(190, 244);
            this.lbl_HargaCargoSkort.Name = "lbl_HargaCargoSkort";
            this.lbl_HargaCargoSkort.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaCargoSkort.TabIndex = 14;
            this.lbl_HargaCargoSkort.Text = "Rp. 259.900,-";
            // 
            // btn_AddDrawstringShort
            // 
            this.btn_AddDrawstringShort.Location = new System.Drawing.Point(12, 268);
            this.btn_AddDrawstringShort.Name = "btn_AddDrawstringShort";
            this.btn_AddDrawstringShort.Size = new System.Drawing.Size(75, 23);
            this.btn_AddDrawstringShort.TabIndex = 10;
            this.btn_AddDrawstringShort.Text = "Add To Cart";
            this.btn_AddDrawstringShort.UseVisualStyleBackColor = true;
            this.btn_AddDrawstringShort.Click += new System.EventHandler(this.btn_AddDrawstringShort_Click);
            // 
            // btn_AddCargoSkort
            // 
            this.btn_AddCargoSkort.Location = new System.Drawing.Point(193, 268);
            this.btn_AddCargoSkort.Name = "btn_AddCargoSkort";
            this.btn_AddCargoSkort.Size = new System.Drawing.Size(75, 23);
            this.btn_AddCargoSkort.TabIndex = 13;
            this.btn_AddCargoSkort.Text = "Add To Cart";
            this.btn_AddCargoSkort.UseVisualStyleBackColor = true;
            this.btn_AddCargoSkort.Click += new System.EventHandler(this.btn_AddCargoSkort_Click);
            // 
            // lbl_HargaDrawstringShorts
            // 
            this.lbl_HargaDrawstringShorts.AutoSize = true;
            this.lbl_HargaDrawstringShorts.Location = new System.Drawing.Point(9, 244);
            this.lbl_HargaDrawstringShorts.Name = "lbl_HargaDrawstringShorts";
            this.lbl_HargaDrawstringShorts.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaDrawstringShorts.TabIndex = 11;
            this.lbl_HargaDrawstringShorts.Text = "Rp. 130.000,-";
            // 
            // lbl_CargoSkort
            // 
            this.lbl_CargoSkort.AutoSize = true;
            this.lbl_CargoSkort.Location = new System.Drawing.Point(190, 225);
            this.lbl_CargoSkort.Name = "lbl_CargoSkort";
            this.lbl_CargoSkort.Size = new System.Drawing.Size(118, 13);
            this.lbl_CargoSkort.TabIndex = 12;
            this.lbl_CargoSkort.Text = "Belted Mini Cargo Skort";
            // 
            // pnl_LongPants
            // 
            this.pnl_LongPants.Controls.Add(this.pbox_BoyfriendJeans);
            this.pnl_LongPants.Controls.Add(this.lbl_HargaParachute);
            this.pnl_LongPants.Controls.Add(this.pbox_CargoTrousers);
            this.pnl_LongPants.Controls.Add(this.btn_AddParachutePants);
            this.pnl_LongPants.Controls.Add(this.pbox_ParachutePants);
            this.pnl_LongPants.Controls.Add(this.lbl_ParachutePants);
            this.pnl_LongPants.Controls.Add(this.lbl_CargoTrousers);
            this.pnl_LongPants.Controls.Add(this.lbl_HargaBoyfriend);
            this.pnl_LongPants.Controls.Add(this.btn_AddCargoTrous);
            this.pnl_LongPants.Controls.Add(this.btn_AddBoyfJeans);
            this.pnl_LongPants.Controls.Add(this.lbl_HargaCargoTrous);
            this.pnl_LongPants.Controls.Add(this.lbl_BoyfriendJeans);
            this.pnl_LongPants.Location = new System.Drawing.Point(9, 30);
            this.pnl_LongPants.Name = "pnl_LongPants";
            this.pnl_LongPants.Size = new System.Drawing.Size(543, 298);
            this.pnl_LongPants.TabIndex = 21;
            this.pnl_LongPants.Visible = false;
            // 
            // pbox_BoyfriendJeans
            // 
            this.pbox_BoyfriendJeans.Image = global::TH_W09_Clothing_Shop.Properties.Resources.boyfriendjeans;
            this.pbox_BoyfriendJeans.Location = new System.Drawing.Point(193, 13);
            this.pbox_BoyfriendJeans.Name = "pbox_BoyfriendJeans";
            this.pbox_BoyfriendJeans.Size = new System.Drawing.Size(142, 206);
            this.pbox_BoyfriendJeans.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_BoyfriendJeans.TabIndex = 7;
            this.pbox_BoyfriendJeans.TabStop = false;
            // 
            // lbl_HargaParachute
            // 
            this.lbl_HargaParachute.AutoSize = true;
            this.lbl_HargaParachute.Location = new System.Drawing.Point(372, 244);
            this.lbl_HargaParachute.Name = "lbl_HargaParachute";
            this.lbl_HargaParachute.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaParachute.TabIndex = 17;
            this.lbl_HargaParachute.Text = "Rp. 200.000,-";
            // 
            // pbox_CargoTrousers
            // 
            this.pbox_CargoTrousers.Image = global::TH_W09_Clothing_Shop.Properties.Resources.cargotrousers;
            this.pbox_CargoTrousers.Location = new System.Drawing.Point(9, 13);
            this.pbox_CargoTrousers.Name = "pbox_CargoTrousers";
            this.pbox_CargoTrousers.Size = new System.Drawing.Size(143, 206);
            this.pbox_CargoTrousers.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_CargoTrousers.TabIndex = 6;
            this.pbox_CargoTrousers.TabStop = false;
            // 
            // btn_AddParachutePants
            // 
            this.btn_AddParachutePants.Location = new System.Drawing.Point(375, 268);
            this.btn_AddParachutePants.Name = "btn_AddParachutePants";
            this.btn_AddParachutePants.Size = new System.Drawing.Size(75, 23);
            this.btn_AddParachutePants.TabIndex = 16;
            this.btn_AddParachutePants.Text = "Add To Cart";
            this.btn_AddParachutePants.UseVisualStyleBackColor = true;
            this.btn_AddParachutePants.Click += new System.EventHandler(this.btn_AddParachutePants_Click);
            // 
            // pbox_ParachutePants
            // 
            this.pbox_ParachutePants.Image = global::TH_W09_Clothing_Shop.Properties.Resources.parachutepants;
            this.pbox_ParachutePants.Location = new System.Drawing.Point(375, 13);
            this.pbox_ParachutePants.Name = "pbox_ParachutePants";
            this.pbox_ParachutePants.Size = new System.Drawing.Size(145, 206);
            this.pbox_ParachutePants.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_ParachutePants.TabIndex = 8;
            this.pbox_ParachutePants.TabStop = false;
            // 
            // lbl_ParachutePants
            // 
            this.lbl_ParachutePants.AutoSize = true;
            this.lbl_ParachutePants.Location = new System.Drawing.Point(372, 225);
            this.lbl_ParachutePants.Name = "lbl_ParachutePants";
            this.lbl_ParachutePants.Size = new System.Drawing.Size(118, 13);
            this.lbl_ParachutePants.TabIndex = 15;
            this.lbl_ParachutePants.Text = "Loose Parachute Pants";
            // 
            // lbl_CargoTrousers
            // 
            this.lbl_CargoTrousers.AutoSize = true;
            this.lbl_CargoTrousers.Location = new System.Drawing.Point(9, 225);
            this.lbl_CargoTrousers.Name = "lbl_CargoTrousers";
            this.lbl_CargoTrousers.Size = new System.Drawing.Size(128, 13);
            this.lbl_CargoTrousers.TabIndex = 9;
            this.lbl_CargoTrousers.Text = "Cargo Trousers with Cuffs";
            // 
            // lbl_HargaBoyfriend
            // 
            this.lbl_HargaBoyfriend.AutoSize = true;
            this.lbl_HargaBoyfriend.Location = new System.Drawing.Point(190, 244);
            this.lbl_HargaBoyfriend.Name = "lbl_HargaBoyfriend";
            this.lbl_HargaBoyfriend.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaBoyfriend.TabIndex = 14;
            this.lbl_HargaBoyfriend.Text = "Rp. 299.900,-";
            // 
            // btn_AddCargoTrous
            // 
            this.btn_AddCargoTrous.Location = new System.Drawing.Point(12, 268);
            this.btn_AddCargoTrous.Name = "btn_AddCargoTrous";
            this.btn_AddCargoTrous.Size = new System.Drawing.Size(75, 23);
            this.btn_AddCargoTrous.TabIndex = 10;
            this.btn_AddCargoTrous.Text = "Add To Cart";
            this.btn_AddCargoTrous.UseVisualStyleBackColor = true;
            this.btn_AddCargoTrous.Click += new System.EventHandler(this.btn_AddCargoTrous_Click);
            // 
            // btn_AddBoyfJeans
            // 
            this.btn_AddBoyfJeans.Location = new System.Drawing.Point(193, 268);
            this.btn_AddBoyfJeans.Name = "btn_AddBoyfJeans";
            this.btn_AddBoyfJeans.Size = new System.Drawing.Size(75, 23);
            this.btn_AddBoyfJeans.TabIndex = 13;
            this.btn_AddBoyfJeans.Text = "Add To Cart";
            this.btn_AddBoyfJeans.UseVisualStyleBackColor = true;
            this.btn_AddBoyfJeans.Click += new System.EventHandler(this.btn_AddBoyfJeans_Click);
            // 
            // lbl_HargaCargoTrous
            // 
            this.lbl_HargaCargoTrous.AutoSize = true;
            this.lbl_HargaCargoTrous.Location = new System.Drawing.Point(9, 244);
            this.lbl_HargaCargoTrous.Name = "lbl_HargaCargoTrous";
            this.lbl_HargaCargoTrous.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaCargoTrous.TabIndex = 11;
            this.lbl_HargaCargoTrous.Text = "Rp. 379.900,-";
            // 
            // lbl_BoyfriendJeans
            // 
            this.lbl_BoyfriendJeans.AutoSize = true;
            this.lbl_BoyfriendJeans.Location = new System.Drawing.Point(190, 225);
            this.lbl_BoyfriendJeans.Name = "lbl_BoyfriendJeans";
            this.lbl_BoyfriendJeans.Size = new System.Drawing.Size(132, 13);
            this.lbl_BoyfriendJeans.TabIndex = 12;
            this.lbl_BoyfriendJeans.Text = "Rolled Up Boyfriend Jeans";
            // 
            // pnl_Shoes
            // 
            this.pnl_Shoes.Controls.Add(this.pbox_BalletFlats);
            this.pnl_Shoes.Controls.Add(this.lbl_HargaCanvas);
            this.pnl_Shoes.Controls.Add(this.pbox_CanvasEspadrilles);
            this.pnl_Shoes.Controls.Add(this.btn_AddSneakers);
            this.pnl_Shoes.Controls.Add(this.pbox_CanvasSneakers);
            this.pnl_Shoes.Controls.Add(this.lbl_CanvasSneakers);
            this.pnl_Shoes.Controls.Add(this.lbl_CanvasEspadrilles);
            this.pnl_Shoes.Controls.Add(this.lbl_HargaBallet);
            this.pnl_Shoes.Controls.Add(this.btn_AddEspadrilles);
            this.pnl_Shoes.Controls.Add(this.btn_AddFlats);
            this.pnl_Shoes.Controls.Add(this.lbl_HargaEspadrilles);
            this.pnl_Shoes.Controls.Add(this.lbl_BalletFlats);
            this.pnl_Shoes.Location = new System.Drawing.Point(10, 28);
            this.pnl_Shoes.Name = "pnl_Shoes";
            this.pnl_Shoes.Size = new System.Drawing.Size(543, 298);
            this.pnl_Shoes.TabIndex = 22;
            this.pnl_Shoes.Visible = false;
            // 
            // pbox_BalletFlats
            // 
            this.pbox_BalletFlats.Image = global::TH_W09_Clothing_Shop.Properties.Resources.balletflats;
            this.pbox_BalletFlats.Location = new System.Drawing.Point(193, 13);
            this.pbox_BalletFlats.Name = "pbox_BalletFlats";
            this.pbox_BalletFlats.Size = new System.Drawing.Size(142, 206);
            this.pbox_BalletFlats.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_BalletFlats.TabIndex = 7;
            this.pbox_BalletFlats.TabStop = false;
            // 
            // lbl_HargaCanvas
            // 
            this.lbl_HargaCanvas.AutoSize = true;
            this.lbl_HargaCanvas.Location = new System.Drawing.Point(372, 244);
            this.lbl_HargaCanvas.Name = "lbl_HargaCanvas";
            this.lbl_HargaCanvas.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaCanvas.TabIndex = 17;
            this.lbl_HargaCanvas.Text = "Rp. 580.000,-";
            // 
            // pbox_CanvasEspadrilles
            // 
            this.pbox_CanvasEspadrilles.Image = global::TH_W09_Clothing_Shop.Properties.Resources.canvasespadrilles;
            this.pbox_CanvasEspadrilles.Location = new System.Drawing.Point(9, 13);
            this.pbox_CanvasEspadrilles.Name = "pbox_CanvasEspadrilles";
            this.pbox_CanvasEspadrilles.Size = new System.Drawing.Size(143, 206);
            this.pbox_CanvasEspadrilles.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_CanvasEspadrilles.TabIndex = 6;
            this.pbox_CanvasEspadrilles.TabStop = false;
            // 
            // btn_AddSneakers
            // 
            this.btn_AddSneakers.Location = new System.Drawing.Point(375, 268);
            this.btn_AddSneakers.Name = "btn_AddSneakers";
            this.btn_AddSneakers.Size = new System.Drawing.Size(75, 23);
            this.btn_AddSneakers.TabIndex = 16;
            this.btn_AddSneakers.Text = "Add To Cart";
            this.btn_AddSneakers.UseVisualStyleBackColor = true;
            this.btn_AddSneakers.Click += new System.EventHandler(this.btn_AddSneakers_Click);
            // 
            // pbox_CanvasSneakers
            // 
            this.pbox_CanvasSneakers.Image = global::TH_W09_Clothing_Shop.Properties.Resources.canvassneakers;
            this.pbox_CanvasSneakers.Location = new System.Drawing.Point(375, 13);
            this.pbox_CanvasSneakers.Name = "pbox_CanvasSneakers";
            this.pbox_CanvasSneakers.Size = new System.Drawing.Size(145, 206);
            this.pbox_CanvasSneakers.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_CanvasSneakers.TabIndex = 8;
            this.pbox_CanvasSneakers.TabStop = false;
            // 
            // lbl_CanvasSneakers
            // 
            this.lbl_CanvasSneakers.AutoSize = true;
            this.lbl_CanvasSneakers.Location = new System.Drawing.Point(372, 225);
            this.lbl_CanvasSneakers.Name = "lbl_CanvasSneakers";
            this.lbl_CanvasSneakers.Size = new System.Drawing.Size(91, 13);
            this.lbl_CanvasSneakers.TabIndex = 15;
            this.lbl_CanvasSneakers.Text = "Canvas Sneakers";
            // 
            // lbl_CanvasEspadrilles
            // 
            this.lbl_CanvasEspadrilles.AutoSize = true;
            this.lbl_CanvasEspadrilles.Location = new System.Drawing.Point(9, 225);
            this.lbl_CanvasEspadrilles.Name = "lbl_CanvasEspadrilles";
            this.lbl_CanvasEspadrilles.Size = new System.Drawing.Size(96, 13);
            this.lbl_CanvasEspadrilles.TabIndex = 9;
            this.lbl_CanvasEspadrilles.Text = "Canvas Espadrilles";
            // 
            // lbl_HargaBallet
            // 
            this.lbl_HargaBallet.AutoSize = true;
            this.lbl_HargaBallet.Location = new System.Drawing.Point(190, 244);
            this.lbl_HargaBallet.Name = "lbl_HargaBallet";
            this.lbl_HargaBallet.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaBallet.TabIndex = 14;
            this.lbl_HargaBallet.Text = "Rp. 399.900,-";
            // 
            // btn_AddEspadrilles
            // 
            this.btn_AddEspadrilles.Location = new System.Drawing.Point(12, 268);
            this.btn_AddEspadrilles.Name = "btn_AddEspadrilles";
            this.btn_AddEspadrilles.Size = new System.Drawing.Size(75, 23);
            this.btn_AddEspadrilles.TabIndex = 10;
            this.btn_AddEspadrilles.Text = "Add To Cart";
            this.btn_AddEspadrilles.UseVisualStyleBackColor = true;
            this.btn_AddEspadrilles.Click += new System.EventHandler(this.btn_AddEspadrilles_Click);
            // 
            // btn_AddFlats
            // 
            this.btn_AddFlats.Location = new System.Drawing.Point(193, 268);
            this.btn_AddFlats.Name = "btn_AddFlats";
            this.btn_AddFlats.Size = new System.Drawing.Size(75, 23);
            this.btn_AddFlats.TabIndex = 13;
            this.btn_AddFlats.Text = "Add To Cart";
            this.btn_AddFlats.UseVisualStyleBackColor = true;
            this.btn_AddFlats.Click += new System.EventHandler(this.btn_AddFlats_Click);
            // 
            // lbl_HargaEspadrilles
            // 
            this.lbl_HargaEspadrilles.AutoSize = true;
            this.lbl_HargaEspadrilles.Location = new System.Drawing.Point(9, 244);
            this.lbl_HargaEspadrilles.Name = "lbl_HargaEspadrilles";
            this.lbl_HargaEspadrilles.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaEspadrilles.TabIndex = 11;
            this.lbl_HargaEspadrilles.Text = "Rp. 359.900,-";
            // 
            // lbl_BalletFlats
            // 
            this.lbl_BalletFlats.AutoSize = true;
            this.lbl_BalletFlats.Location = new System.Drawing.Point(190, 225);
            this.lbl_BalletFlats.Name = "lbl_BalletFlats";
            this.lbl_BalletFlats.Size = new System.Drawing.Size(58, 13);
            this.lbl_BalletFlats.TabIndex = 12;
            this.lbl_BalletFlats.Text = "Ballet Flats";
            // 
            // pnl_Jeweleries
            // 
            this.pnl_Jeweleries.Controls.Add(this.pbox_ChunkyDome);
            this.pnl_Jeweleries.Controls.Add(this.lbl_HargaRing);
            this.pnl_Jeweleries.Controls.Add(this.pbox_HeartPendant);
            this.pnl_Jeweleries.Controls.Add(this.btn_AddRing);
            this.pnl_Jeweleries.Controls.Add(this.pbox_RingPendant);
            this.pnl_Jeweleries.Controls.Add(this.lbl_RingPendant);
            this.pnl_Jeweleries.Controls.Add(this.lbl_HeartPendant);
            this.pnl_Jeweleries.Controls.Add(this.lbl_HargaDome);
            this.pnl_Jeweleries.Controls.Add(this.btn_AddHeart);
            this.pnl_Jeweleries.Controls.Add(this.btn_AddDome);
            this.pnl_Jeweleries.Controls.Add(this.lbl_HargaHeart);
            this.pnl_Jeweleries.Controls.Add(this.lbl_ChunkyDome);
            this.pnl_Jeweleries.Location = new System.Drawing.Point(9, 29);
            this.pnl_Jeweleries.Name = "pnl_Jeweleries";
            this.pnl_Jeweleries.Size = new System.Drawing.Size(543, 298);
            this.pnl_Jeweleries.TabIndex = 23;
            this.pnl_Jeweleries.Visible = false;
            // 
            // pbox_ChunkyDome
            // 
            this.pbox_ChunkyDome.Image = global::TH_W09_Clothing_Shop.Properties.Resources.chunkydome;
            this.pbox_ChunkyDome.Location = new System.Drawing.Point(193, 13);
            this.pbox_ChunkyDome.Name = "pbox_ChunkyDome";
            this.pbox_ChunkyDome.Size = new System.Drawing.Size(142, 206);
            this.pbox_ChunkyDome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_ChunkyDome.TabIndex = 7;
            this.pbox_ChunkyDome.TabStop = false;
            // 
            // lbl_HargaRing
            // 
            this.lbl_HargaRing.AutoSize = true;
            this.lbl_HargaRing.Location = new System.Drawing.Point(372, 244);
            this.lbl_HargaRing.Name = "lbl_HargaRing";
            this.lbl_HargaRing.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaRing.TabIndex = 17;
            this.lbl_HargaRing.Text = "Rp. 249.900,-";
            // 
            // pbox_HeartPendant
            // 
            this.pbox_HeartPendant.Image = global::TH_W09_Clothing_Shop.Properties.Resources.heartpendant;
            this.pbox_HeartPendant.Location = new System.Drawing.Point(9, 13);
            this.pbox_HeartPendant.Name = "pbox_HeartPendant";
            this.pbox_HeartPendant.Size = new System.Drawing.Size(143, 206);
            this.pbox_HeartPendant.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_HeartPendant.TabIndex = 6;
            this.pbox_HeartPendant.TabStop = false;
            // 
            // btn_AddRing
            // 
            this.btn_AddRing.Location = new System.Drawing.Point(375, 268);
            this.btn_AddRing.Name = "btn_AddRing";
            this.btn_AddRing.Size = new System.Drawing.Size(75, 23);
            this.btn_AddRing.TabIndex = 16;
            this.btn_AddRing.Text = "Add To Cart";
            this.btn_AddRing.UseVisualStyleBackColor = true;
            this.btn_AddRing.Click += new System.EventHandler(this.btn_AddRing_Click);
            // 
            // pbox_RingPendant
            // 
            this.pbox_RingPendant.Image = global::TH_W09_Clothing_Shop.Properties.Resources.ringpendant;
            this.pbox_RingPendant.Location = new System.Drawing.Point(375, 13);
            this.pbox_RingPendant.Name = "pbox_RingPendant";
            this.pbox_RingPendant.Size = new System.Drawing.Size(145, 206);
            this.pbox_RingPendant.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_RingPendant.TabIndex = 8;
            this.pbox_RingPendant.TabStop = false;
            // 
            // lbl_RingPendant
            // 
            this.lbl_RingPendant.AutoSize = true;
            this.lbl_RingPendant.Location = new System.Drawing.Point(372, 225);
            this.lbl_RingPendant.Name = "lbl_RingPendant";
            this.lbl_RingPendant.Size = new System.Drawing.Size(148, 13);
            this.lbl_RingPendant.TabIndex = 15;
            this.lbl_RingPendant.Text = "Necklace with Ring Pendants";
            // 
            // lbl_HeartPendant
            // 
            this.lbl_HeartPendant.AutoSize = true;
            this.lbl_HeartPendant.Location = new System.Drawing.Point(9, 225);
            this.lbl_HeartPendant.Name = "lbl_HeartPendant";
            this.lbl_HeartPendant.Size = new System.Drawing.Size(124, 13);
            this.lbl_HeartPendant.TabIndex = 9;
            this.lbl_HeartPendant.Text = "Heart-pendant Necklace";
            // 
            // lbl_HargaDome
            // 
            this.lbl_HargaDome.AutoSize = true;
            this.lbl_HargaDome.Location = new System.Drawing.Point(190, 244);
            this.lbl_HargaDome.Name = "lbl_HargaDome";
            this.lbl_HargaDome.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaDome.TabIndex = 14;
            this.lbl_HargaDome.Text = "Rp. 359.000,-";
            // 
            // btn_AddHeart
            // 
            this.btn_AddHeart.Location = new System.Drawing.Point(12, 268);
            this.btn_AddHeart.Name = "btn_AddHeart";
            this.btn_AddHeart.Size = new System.Drawing.Size(75, 23);
            this.btn_AddHeart.TabIndex = 10;
            this.btn_AddHeart.Text = "Add To Cart";
            this.btn_AddHeart.UseVisualStyleBackColor = true;
            this.btn_AddHeart.Click += new System.EventHandler(this.btn_AddHeart_Click);
            // 
            // btn_AddDome
            // 
            this.btn_AddDome.Location = new System.Drawing.Point(193, 268);
            this.btn_AddDome.Name = "btn_AddDome";
            this.btn_AddDome.Size = new System.Drawing.Size(75, 23);
            this.btn_AddDome.TabIndex = 13;
            this.btn_AddDome.Text = "Add To Cart";
            this.btn_AddDome.UseVisualStyleBackColor = true;
            this.btn_AddDome.Click += new System.EventHandler(this.btn_AddDome_Click);
            // 
            // lbl_HargaHeart
            // 
            this.lbl_HargaHeart.AutoSize = true;
            this.lbl_HargaHeart.Location = new System.Drawing.Point(9, 244);
            this.lbl_HargaHeart.Name = "lbl_HargaHeart";
            this.lbl_HargaHeart.Size = new System.Drawing.Size(72, 13);
            this.lbl_HargaHeart.TabIndex = 11;
            this.lbl_HargaHeart.Text = "Rp. 170.000,-";
            // 
            // lbl_ChunkyDome
            // 
            this.lbl_ChunkyDome.AutoSize = true;
            this.lbl_ChunkyDome.Location = new System.Drawing.Point(190, 225);
            this.lbl_ChunkyDome.Name = "lbl_ChunkyDome";
            this.lbl_ChunkyDome.Size = new System.Drawing.Size(115, 13);
            this.lbl_ChunkyDome.TabIndex = 12;
            this.lbl_ChunkyDome.Text = "Chunky Dome Earrings";
            // 
            // pnl_Others
            // 
            this.pnl_Others.Controls.Add(this.txtbox_ItemPrice);
            this.pnl_Others.Controls.Add(this.lbl_ItemPrice);
            this.pnl_Others.Controls.Add(this.txtbox_ItemName);
            this.pnl_Others.Controls.Add(this.lbl_ItemName);
            this.pnl_Others.Controls.Add(this.btn_Upload);
            this.pnl_Others.Controls.Add(this.pbox_Others);
            this.pnl_Others.Controls.Add(this.lbl_Upload);
            this.pnl_Others.Controls.Add(this.btn_AddNewItem);
            this.pnl_Others.Location = new System.Drawing.Point(10, 28);
            this.pnl_Others.Name = "pnl_Others";
            this.pnl_Others.Size = new System.Drawing.Size(543, 298);
            this.pnl_Others.TabIndex = 23;
            this.pnl_Others.Visible = false;
            // 
            // txtbox_ItemPrice
            // 
            this.txtbox_ItemPrice.Enabled = false;
            this.txtbox_ItemPrice.Location = new System.Drawing.Point(276, 129);
            this.txtbox_ItemPrice.Name = "txtbox_ItemPrice";
            this.txtbox_ItemPrice.Size = new System.Drawing.Size(102, 20);
            this.txtbox_ItemPrice.TabIndex = 20;
            this.txtbox_ItemPrice.TextChanged += new System.EventHandler(this.txtbox_ItemPrice_TextChanged);
            this.txtbox_ItemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbox_ItemPrice_KeyPress);
            // 
            // lbl_ItemPrice
            // 
            this.lbl_ItemPrice.AutoSize = true;
            this.lbl_ItemPrice.Location = new System.Drawing.Point(273, 112);
            this.lbl_ItemPrice.Name = "lbl_ItemPrice";
            this.lbl_ItemPrice.Size = new System.Drawing.Size(57, 13);
            this.lbl_ItemPrice.TabIndex = 19;
            this.lbl_ItemPrice.Text = "Item Price:";
            // 
            // txtbox_ItemName
            // 
            this.txtbox_ItemName.Enabled = false;
            this.txtbox_ItemName.Location = new System.Drawing.Point(276, 75);
            this.txtbox_ItemName.Name = "txtbox_ItemName";
            this.txtbox_ItemName.Size = new System.Drawing.Size(102, 20);
            this.txtbox_ItemName.TabIndex = 18;
            this.txtbox_ItemName.TextChanged += new System.EventHandler(this.txtbox_ItemName_TextChanged);
            // 
            // lbl_ItemName
            // 
            this.lbl_ItemName.AutoSize = true;
            this.lbl_ItemName.Location = new System.Drawing.Point(273, 58);
            this.lbl_ItemName.Name = "lbl_ItemName";
            this.lbl_ItemName.Size = new System.Drawing.Size(61, 13);
            this.lbl_ItemName.TabIndex = 17;
            this.lbl_ItemName.Text = "Item Name:";
            // 
            // btn_Upload
            // 
            this.btn_Upload.Location = new System.Drawing.Point(189, 15);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(100, 23);
            this.btn_Upload.TabIndex = 16;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.UseVisualStyleBackColor = true;
            this.btn_Upload.Click += new System.EventHandler(this.btn_Upload_Click);
            // 
            // pbox_Others
            // 
            this.pbox_Others.Location = new System.Drawing.Point(111, 58);
            this.pbox_Others.Name = "pbox_Others";
            this.pbox_Others.Size = new System.Drawing.Size(143, 206);
            this.pbox_Others.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_Others.TabIndex = 6;
            this.pbox_Others.TabStop = false;
            // 
            // lbl_Upload
            // 
            this.lbl_Upload.AutoSize = true;
            this.lbl_Upload.Location = new System.Drawing.Point(110, 19);
            this.lbl_Upload.Name = "lbl_Upload";
            this.lbl_Upload.Size = new System.Drawing.Size(73, 13);
            this.lbl_Upload.TabIndex = 15;
            this.lbl_Upload.Text = "Upload Image";
            // 
            // btn_AddNewItem
            // 
            this.btn_AddNewItem.Enabled = false;
            this.btn_AddNewItem.Location = new System.Drawing.Point(276, 241);
            this.btn_AddNewItem.Name = "btn_AddNewItem";
            this.btn_AddNewItem.Size = new System.Drawing.Size(102, 23);
            this.btn_AddNewItem.TabIndex = 10;
            this.btn_AddNewItem.Text = "Add To Cart";
            this.btn_AddNewItem.UseVisualStyleBackColor = true;
            this.btn_AddNewItem.Click += new System.EventHandler(this.btn_AddNewItem_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(946, 376);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(74, 32);
            this.btn_Delete.TabIndex = 21;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // Form_Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1032, 478);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.pnl_Others);
            this.Controls.Add(this.pnl_Shoes);
            this.Controls.Add(this.pnl_LongPants);
            this.Controls.Add(this.pnl_Jeweleries);
            this.Controls.Add(this.pnl_Pants);
            this.Controls.Add(this.pnl_Shirt);
            this.Controls.Add(this.pnl_TShirt);
            this.Controls.Add(this.txtbox_Total);
            this.Controls.Add(this.lbl_Total);
            this.Controls.Add(this.txtbox_SubTotal);
            this.Controls.Add(this.lbl_SubTotal);
            this.Controls.Add(this.dgv_Cart);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form_Shop";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form_Shop_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Cart)).EndInit();
            this.pnl_TShirt.ResumeLayout(false);
            this.pnl_TShirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_croptee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_basictee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_graphictee)).EndInit();
            this.pnl_Shirt.ResumeLayout(false);
            this.pnl_Shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_NotchCollarBlouse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_PeterpanCollarBlouse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_PrintedBlouse)).EndInit();
            this.pnl_Pants.ResumeLayout(false);
            this.pnl_Pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_CargoSkort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_DrawstringShorts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_PocketShorts)).EndInit();
            this.pnl_LongPants.ResumeLayout(false);
            this.pnl_LongPants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_BoyfriendJeans)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_CargoTrousers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_ParachutePants)).EndInit();
            this.pnl_Shoes.ResumeLayout(false);
            this.pnl_Shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_BalletFlats)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_CanvasEspadrilles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_CanvasSneakers)).EndInit();
            this.pnl_Jeweleries.ResumeLayout(false);
            this.pnl_Jeweleries.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_ChunkyDome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_HeartPendant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_RingPendant)).EndInit();
            this.pnl_Others.ResumeLayout(false);
            this.pnl_Others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_Others)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.DataGridView dgv_Cart;
        private System.Windows.Forms.Label lbl_SubTotal;
        private System.Windows.Forms.TextBox txtbox_SubTotal;
        private System.Windows.Forms.TextBox txtbox_Total;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jeweleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.PictureBox pbox_basictee;
        private System.Windows.Forms.PictureBox pbox_croptee;
        private System.Windows.Forms.PictureBox pbox_graphictee;
        private System.Windows.Forms.Label lbl_BasicTee;
        private System.Windows.Forms.Button btn_AddBasicTee;
        private System.Windows.Forms.Label lbl_HargaBasicTee;
        private System.Windows.Forms.Label lbl_HargaCropTee;
        private System.Windows.Forms.Button btn_AddCropTee;
        private System.Windows.Forms.Label lbl_CropTee;
        private System.Windows.Forms.Label lbl_HargaGraphicTee;
        private System.Windows.Forms.Button btn_AddGraphicTee;
        private System.Windows.Forms.Label lbl_GraphicTee;
        private System.Windows.Forms.Panel pnl_TShirt;
        private System.Windows.Forms.Panel pnl_Shirt;
        private System.Windows.Forms.PictureBox pbox_NotchCollarBlouse;
        private System.Windows.Forms.Label lbl_HargaPrintedBlouse;
        private System.Windows.Forms.PictureBox pbox_PeterpanCollarBlouse;
        private System.Windows.Forms.Button btn_AddPrintedBlouse;
        private System.Windows.Forms.PictureBox pbox_PrintedBlouse;
        private System.Windows.Forms.Label lbl_PrintedBlouse;
        private System.Windows.Forms.Label lbl_PeterpanBlouse;
        private System.Windows.Forms.Label lbl_HargaNotchBlouse;
        private System.Windows.Forms.Button btn_AddPeterpanBlouse;
        private System.Windows.Forms.Button btn_AddNotchBlouse;
        private System.Windows.Forms.Label lbl_HargaPeterpanBlouse;
        private System.Windows.Forms.Label lbl_NotchBlouse;
        private System.Windows.Forms.Panel pnl_Pants;
        private System.Windows.Forms.PictureBox pbox_CargoSkort;
        private System.Windows.Forms.Label lbl_HargaPocketShorts;
        private System.Windows.Forms.PictureBox pbox_DrawstringShorts;
        private System.Windows.Forms.Button btn_AddPocketShorts;
        private System.Windows.Forms.PictureBox pbox_PocketShorts;
        private System.Windows.Forms.Label lbl_PocketShorts;
        private System.Windows.Forms.Label lbl_DrawstringShorts;
        private System.Windows.Forms.Label lbl_HargaCargoSkort;
        private System.Windows.Forms.Button btn_AddDrawstringShort;
        private System.Windows.Forms.Button btn_AddCargoSkort;
        private System.Windows.Forms.Label lbl_HargaDrawstringShorts;
        private System.Windows.Forms.Label lbl_CargoSkort;
        private System.Windows.Forms.Panel pnl_LongPants;
        private System.Windows.Forms.PictureBox pbox_BoyfriendJeans;
        private System.Windows.Forms.Label lbl_HargaParachute;
        private System.Windows.Forms.PictureBox pbox_CargoTrousers;
        private System.Windows.Forms.Button btn_AddParachutePants;
        private System.Windows.Forms.PictureBox pbox_ParachutePants;
        private System.Windows.Forms.Label lbl_ParachutePants;
        private System.Windows.Forms.Label lbl_CargoTrousers;
        private System.Windows.Forms.Label lbl_HargaBoyfriend;
        private System.Windows.Forms.Button btn_AddCargoTrous;
        private System.Windows.Forms.Button btn_AddBoyfJeans;
        private System.Windows.Forms.Label lbl_HargaCargoTrous;
        private System.Windows.Forms.Label lbl_BoyfriendJeans;
        private System.Windows.Forms.Panel pnl_Shoes;
        private System.Windows.Forms.PictureBox pbox_BalletFlats;
        private System.Windows.Forms.Label lbl_HargaCanvas;
        private System.Windows.Forms.PictureBox pbox_CanvasEspadrilles;
        private System.Windows.Forms.Button btn_AddSneakers;
        private System.Windows.Forms.PictureBox pbox_CanvasSneakers;
        private System.Windows.Forms.Label lbl_CanvasSneakers;
        private System.Windows.Forms.Label lbl_CanvasEspadrilles;
        private System.Windows.Forms.Label lbl_HargaBallet;
        private System.Windows.Forms.Button btn_AddEspadrilles;
        private System.Windows.Forms.Button btn_AddFlats;
        private System.Windows.Forms.Label lbl_HargaEspadrilles;
        private System.Windows.Forms.Label lbl_BalletFlats;
        private System.Windows.Forms.Panel pnl_Jeweleries;
        private System.Windows.Forms.PictureBox pbox_ChunkyDome;
        private System.Windows.Forms.Label lbl_HargaRing;
        private System.Windows.Forms.PictureBox pbox_HeartPendant;
        private System.Windows.Forms.Button btn_AddRing;
        private System.Windows.Forms.PictureBox pbox_RingPendant;
        private System.Windows.Forms.Label lbl_RingPendant;
        private System.Windows.Forms.Label lbl_HeartPendant;
        private System.Windows.Forms.Label lbl_HargaDome;
        private System.Windows.Forms.Button btn_AddHeart;
        private System.Windows.Forms.Button btn_AddDome;
        private System.Windows.Forms.Label lbl_HargaHeart;
        private System.Windows.Forms.Label lbl_ChunkyDome;
        private System.Windows.Forms.Panel pnl_Others;
        private System.Windows.Forms.PictureBox pbox_Others;
        private System.Windows.Forms.Label lbl_Upload;
        private System.Windows.Forms.Button btn_AddNewItem;
        private System.Windows.Forms.Button btn_Upload;
        private System.Windows.Forms.TextBox txtbox_ItemPrice;
        private System.Windows.Forms.Label lbl_ItemPrice;
        private System.Windows.Forms.TextBox txtbox_ItemName;
        private System.Windows.Forms.Label lbl_ItemName;
        private System.Windows.Forms.Button btn_Delete;
    }
}

